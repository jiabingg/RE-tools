# Inline Generation Reference

When the `generate_viewer.py` script is not accessible (e.g., skill path not mounted), follow this inline approach directly in the conversation.

## Complete Inline Workflow

```python
python3 << 'PYEOF'
import base64, os, json

# ── CONFIG ── (edit these)
PDF_PATH = "/mnt/user-data/uploads/YOUR_FILE.pdf"
OUTPUT_PATH = "/mnt/user-data/outputs/YOUR_VIEWER.html"
DPI = 120          # Adjust: 100 for large docs, 150 for small docs
QUALITY = 70       # JPEG quality: 55-85
TITLE = "Document Title Here"
SUBTITLE = "Subtitle or description here"
PAGES_DIR = "/home/claude/pages"

# Section map — EDIT THIS for each document
# Each tuple: (id, label, icon, group, [page_numbers])
SECTIONS = [
    ("cover", "Cover Page", "📄", "Front Matter", [1]),
    ("toc", "Table of Contents", "📑", "Front Matter", [2, 3]),
    # ... add all sections here ...
]

# ── RASTERIZE ──
os.makedirs(PAGES_DIR, exist_ok=True)
os.system(f"pdftoppm -jpeg -jpegopt quality={QUALITY} -r {DPI} '{PDF_PATH}' {PAGES_DIR}/page")

# ── LOAD PAGES ──
import glob
page_b64 = {}
for fpath in sorted(glob.glob(f"{PAGES_DIR}/page-*.jpg")):
    num = int(os.path.basename(fpath).replace("page-","").replace(".jpg",""))
    with open(fpath, "rb") as f:
        page_b64[num] = base64.b64encode(f.read()).decode("ascii")
total_pages = max(page_b64.keys())
print(f"Loaded {len(page_b64)} pages")

# ── BUILD JS DATA ──
page_js = "const PAGE_DATA={" + ",".join(f'"{k}":"{v}"' for k,v in sorted(page_b64.items())) + "};"
sections_list = [{"id":s[0],"label":s[1],"icon":s[2],"group":s[3],"pages":s[4]} for s in SECTIONS]
sections_json = json.dumps(sections_list)

# ── WRITE HTML ──
# Read the HTML template from the skill's scripts/generate_viewer.py HTML_TEMPLATE constant,
# or use the template in references/html-template.md
# Replace placeholders: {{TITLE}}, {{SUBTITLE}}, {{PAGE_JS}}, {{SECTIONS_JSON}}, 
#   {{TOTAL_PAGES}}, {{MULTI_MODE}} (false), {{MULTI_TABS_HTML}} (""), {{MULTI_DATA_JS}} ("")

html = HTML_TEMPLATE  # (paste the template here or read from file)
html = html.replace("{{TITLE}}", TITLE)
html = html.replace("{{SUBTITLE}}", SUBTITLE)
html = html.replace("{{PAGE_JS}}", page_js)
html = html.replace("{{SECTIONS_JSON}}", sections_json)
html = html.replace("{{TOTAL_PAGES}}", str(total_pages))
html = html.replace("{{MULTI_MODE}}", "false")
html = html.replace("{{MULTI_TABS_HTML}}", "")
html = html.replace("{{MULTI_DATA_JS}}", "")

with open(OUTPUT_PATH, "w") as f:
    f.write(html)
print(f"Done: {OUTPUT_PATH} ({os.path.getsize(OUTPUT_PATH)/1024/1024:.1f} MB)")
PYEOF
```

## Key Points for Inline Use

1. **Copy the HTML_TEMPLATE** from `scripts/generate_viewer.py` into your Python code as a triple-quoted string.
2. **Define SECTIONS carefully** — this is the part that changes for every document. Read the PDF's TOC first.
3. **Adjust DPI and QUALITY** based on page count to keep total size under 15 MB.
4. **Always verify page count** matches what you expect before building HTML.

## Figuring Out the Section Map

The hardest part is defining the correct section-to-page mapping. Here's the process:

1. Extract the TOC text:
   ```bash
   pdftotext -f 2 -l 4 document.pdf - | head -80
   ```

2. Look at any page with `pdftoppm` + view tool to verify where sections start/end:
   ```bash
   pdftoppm -jpeg -r 100 -f 5 -l 5 document.pdf /tmp/check
   ```
   Then use the `view` tool on the resulting image.

3. Cross-reference with the actual PDF document structure in your context window if the PDF content was provided as text.

4. When in doubt, **include a page in both the ending section and the starting section** — it's better to show a boundary page twice than to miss content.
