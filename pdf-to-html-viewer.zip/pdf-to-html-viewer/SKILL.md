---
name: pdf-to-html-viewer
description: "Convert PDF documents into self-contained, interactive HTML viewer pages with faithful page-image reproduction. Use this skill whenever the user wants to: browse a PDF as an HTML page, convert a PDF to HTML for interactive viewing, create a navigable HTML version of a PDF document, build a section-by-section document browser from a PDF, make a PDF viewable in a web browser without a PDF reader, or create an index/viewer page for one or more PDF files. Also trigger when the user mentions 'PDF to HTML', 'browse PDF', 'view PDF in browser', 'HTML viewer for PDF', 'document browser', 'convert PDF to web page', or wants to split a PDF into sections for navigation. This skill produces exact visual reproductions — not text extraction or summarization."
---

# PDF-to-HTML Viewer Skill

## Purpose

Convert one or more PDF files into a single self-contained HTML file that faithfully reproduces every page as a rasterized image, organized into navigable sections with a sidebar, search, and zoom controls. The output is a polished, interactive document browser — not a text conversion or summary.

## Core Principle: Faithful Reproduction

**This skill does NOT extract or rewrite PDF text.** It rasterizes each page to a JPEG image and embeds them in HTML. The user sees exactly what the original PDF contains — every figure, table, equation, signature, header, and formatting detail preserved perfectly.

## When to Use

- User uploads a PDF and asks to "convert to HTML" or "make it browsable"
- User wants to view/navigate a PDF document interactively in a browser
- User asks for an "index page" or "viewer" for one or more PDFs
- User wants section-by-section navigation of a long document
- User wants to compare multiple PDF documents side by side in HTML
- User says "browse", "view", "navigate", or "interactive" in relation to a PDF

## When NOT to Use

- User wants to extract text/data FROM a PDF (use pdf-reading skill)
- User wants to create/edit/merge PDFs (use pdf skill)
- User wants a Word doc version of a PDF (use docx skill)

---

## Step-by-Step Workflow

### Step 1: Understand the Document Structure

Before writing any code, examine the PDF to understand its organization:

```bash
# Get page count and metadata
pdfinfo /mnt/user-data/uploads/FILENAME.pdf

# Quick text check to understand content
pdftotext -f 1 -l 3 /mnt/user-data/uploads/FILENAME.pdf - | head -60
```

If the PDF has a table of contents, read it carefully. Ask the user:
- Do they want specific section groupings, or should you infer from the TOC?
- Are there multiple PDFs to combine into one viewer?

### Step 2: Rasterize All Pages

Convert every page to JPEG. Balance quality vs. file size:

| Use Case | DPI | JPEG Quality | Approx Size/Page |
|----------|-----|-------------|------------------|
| Quick browse (< 30 pages) | 150 | 75 | ~150 KB |
| Standard (30–80 pages) | 120 | 60–70 | ~100 KB |
| Large docs (80+ pages) | 100 | 55 | ~70 KB |
| Max quality (< 15 pages) | 200 | 85 | ~300 KB |

**Target: keep total HTML file under 15 MB.** Adjust DPI/quality to fit.

```bash
mkdir -p /home/claude/pages
pdftoppm -jpeg -jpegopt quality=70 -r 120 \
  /mnt/user-data/uploads/FILENAME.pdf \
  /home/claude/pages/page

# Verify
echo "Pages: $(ls /home/claude/pages/*.jpg | wc -l)"
du -sh /home/claude/pages/
```

### Step 3: Define the Section Map

Create a Python list mapping document sections to page ranges. **This is the most important step — get it right.**

Rules for section mapping:
- **Use the EXACT section labels from the document.** Do not rename, abbreviate, or "fix" headings. If the document says "A. ES(1)" then the label is "A. ES(1)". If it says "B. GS" not "GS(2)", use "B. GS".
- **Respect the document's own hierarchy.** Group sections the way the document groups them (e.g., "2. Engineering Study" as a group containing subsections A through F).
- **Pages can appear in multiple sections** if a page contains the end of one section and the start of another.
- **Include front matter** (cover, TOC, lists of figures/tables) as separate sections.
- **Include appendices** as sections even if they're just reference lists.

```python
# Example section map structure
sections = [
    # (id, label, icon, group_name, [page_numbers])
    ("cover", "Cover Page", "📄", "Front Matter", [1]),
    ("toc", "Table of Contents", "📑", "Front Matter", [2, 3]),
    ("sec1", "1 — Section Title", "✍️", "1. Major Section", [4]),
    ("sec2a", "A. Subsection Title", "📐", "2. Major Section", [5, 6, 7]),
    ("sec2b", "B. Subsection Title", "🗺️", "2. Major Section", [8, 9]),
    # ... etc
]
```

Icon suggestions by content type:
- 📄 Cover/title pages
- 📑 Table of contents
- 📊 Tables, data
- 🗺️ Maps
- 📐 Calculations, engineering
- 🪨 Geology
- 🛢️ Reservoir/fluid data
- 💉 Injection
- 🔧 Equipment, mechanical
- 📋 Lists, compendiums
- ⚡ Pressure, testing
- 💧 Water, fluid
- 🏔️ Structure, cross-sections
- 🏭 Facilities
- 📎 Appendices

### Step 4: Generate the HTML

Use the Python generation script at `scripts/generate_viewer.py` (see reference). The script:

1. Reads all page JPEGs and converts to base64
2. Builds a section map from your definitions
3. Generates a single self-contained HTML file with all images embedded
4. Outputs to `/mnt/user-data/outputs/`

```bash
python3 /path/to/skill/scripts/generate_viewer.py \
  --pages-dir /home/claude/pages \
  --output /mnt/user-data/outputs/VIEWER_NAME.html \
  --title "Document Title" \
  --subtitle "Subtitle or description" \
  --sections-json /home/claude/sections.json
```

**If the script is not available**, use the inline generation approach described in `references/inline-generation.md`.

### Step 5: Present to User

```python
# Use present_files to share the HTML
present_files(["/mnt/user-data/outputs/VIEWER_NAME.html"])
```

---

## Multi-Document Viewers

When the user provides multiple PDFs:

1. Rasterize each PDF into separate page directories
2. Create section maps for each document
3. Add a **tab bar** or **document selector** in the header
4. Store page data per-document in JS objects
5. Switching documents rebuilds the sidebar and content area

The tab bar uses the same styling as the sidebar but is horizontal in the top bar:

```javascript
// Multi-doc structure
const DOCUMENTS = {
  doc1: { title: "Doc 1 Title", sections: [...], pages: {...} },
  doc2: { title: "Doc 2 Title", sections: [...], pages: {...} }
};
let currentDoc = 'doc1';
```

---

## HTML Viewer Features (Required)

Every generated viewer MUST include:

1. **Sidebar navigation** — grouped by document section, with icons and page numbers
2. **Search/filter** — text input that filters sidebar items by label and group name
3. **Page images** — faithful JPEG reproductions of each PDF page, centered
4. **Page indicators** — "Page X of N" label under each image and in the top bar
5. **Zoom controls** — +/−/fit buttons (fixed position, bottom-right corner)
6. **Keyboard navigation** — Alt+Up/Down to step through sections
7. **Dark theme** — dark background with white page images (paper-on-desk feel)
8. **Responsive** — sidebar collapses on narrow screens
9. **Lazy rendering** — only render images for the active section (critical for large docs)

---

## Styling Specification

Use these exact CSS variables for consistency:

```css
:root {
  --bg: #101218;
  --surface: #181b24;
  --surface2: #1f2330;
  --border: #2a2f40;
  --text: #d8dae6;
  --text-dim: #7a7f96;
  --accent: #4d8cf5;
  --accent-glow: rgba(77,140,245,0.12);
  --sidebar-w: 320px;
  --topbar-h: 56px;
}
```

Fonts: `'DM Sans'` for UI, `'Source Serif 4'` for the logo, `'JetBrains Mono'` for page indicators. Load from Google Fonts CDN.

Page images: `max-width: 820px`, white background, subtle border and shadow, `border-radius: 3px`.

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| HTML file too large (>15 MB) | Lower DPI to 100, quality to 50. Or split into multiple HTML files by major section. |
| Pages look blurry | Increase DPI to 150+. May need to accept larger file size. |
| Section labels wrong | Re-read the PDF TOC carefully. Use exact document wording, not paraphrased labels. |
| Some pages missing | Check `pdftoppm` output — filenames are zero-padded based on total page count (e.g., `page-01` vs `page-001`). Use `ls` to find actual filenames. |
| Dark maps/figures hard to see | The white page background preserves original rendering. Zoom in if needed. |

---

## File References

- `scripts/generate_viewer.py` — Main generation script (read before using)
- `references/inline-generation.md` — Full inline Python code for when the script isn't available
- `references/html-template.md` — The complete HTML/CSS/JS template with all features
