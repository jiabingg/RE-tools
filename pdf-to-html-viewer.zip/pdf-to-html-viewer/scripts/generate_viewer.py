#!/usr/bin/env python3
"""
generate_viewer.py — Convert rasterized PDF pages into a self-contained HTML viewer.

Usage:
    python3 generate_viewer.py \
        --pages-dir /home/claude/pages \
        --output /mnt/user-data/outputs/viewer.html \
        --title "Document Title" \
        --subtitle "Optional subtitle" \
        --sections-json /home/claude/sections.json

The sections JSON file should contain a list of objects:
[
  {
    "id": "cover",
    "label": "Cover Page",
    "icon": "📄",
    "group": "Front Matter",
    "pages": [1]
  },
  ...
]

For multi-document viewers, use --multi mode with a manifest JSON:
    python3 generate_viewer.py \
        --multi /home/claude/manifest.json \
        --output /mnt/user-data/outputs/viewer.html

Manifest JSON structure:
{
  "documents": [
    {
      "key": "doc1",
      "tab_label": "Short Tab Label",
      "title": "Full Title",
      "pages_dir": "/home/claude/pages_doc1",
      "sections_json": "/home/claude/sections_doc1.json"
    },
    ...
  ]
}
"""

import argparse
import base64
import json
import os
import sys
import glob


def load_page_images(pages_dir):
    """Load all page-*.jpg files from a directory, return dict of {page_num: base64_str}."""
    page_b64 = {}
    jpg_files = sorted(glob.glob(os.path.join(pages_dir, "page-*.jpg")))
    if not jpg_files:
        print(f"ERROR: No page-*.jpg files found in {pages_dir}", file=sys.stderr)
        sys.exit(1)
    for fpath in jpg_files:
        # Extract page number from filename like page-01.jpg or page-001.jpg
        basename = os.path.basename(fpath)
        num_str = basename.replace("page-", "").replace(".jpg", "")
        page_num = int(num_str)
        with open(fpath, "rb") as f:
            page_b64[page_num] = base64.b64encode(f.read()).decode("ascii")
    print(f"Loaded {len(page_b64)} pages from {pages_dir}")
    return page_b64


def load_sections(sections_json_path):
    """Load sections definition from JSON file."""
    with open(sections_json_path, "r") as f:
        sections = json.load(f)
    # Validate
    for i, sec in enumerate(sections):
        for key in ("id", "label", "icon", "group", "pages"):
            if key not in sec:
                print(f"ERROR: Section {i} missing required key '{key}'", file=sys.stderr)
                sys.exit(1)
        if not isinstance(sec["pages"], list) or len(sec["pages"]) == 0:
            print(f"ERROR: Section '{sec['id']}' has empty or non-list pages", file=sys.stderr)
            sys.exit(1)
    print(f"Loaded {len(sections)} sections from {sections_json_path}")
    return sections


def build_page_js(page_b64):
    """Build JS const string for page data."""
    parts = [f'"{k}":"{v}"' for k, v in sorted(page_b64.items())]
    return "const PAGE_DATA={" + ",".join(parts) + "};"


def build_single_doc_html(title, subtitle, page_js, sections_json, total_pages):
    """Build complete HTML string for a single-document viewer."""
    return HTML_TEMPLATE.replace("{{TITLE}}", title)\
        .replace("{{SUBTITLE}}", subtitle)\
        .replace("{{PAGE_JS}}", page_js)\
        .replace("{{SECTIONS_JSON}}", sections_json)\
        .replace("{{TOTAL_PAGES}}", str(total_pages))\
        .replace("{{MULTI_MODE}}", "false")\
        .replace("{{MULTI_TABS_HTML}}", "")\
        .replace("{{MULTI_DATA_JS}}", "")


def build_multi_doc_html(documents_config, output_path):
    """Build complete HTML for a multi-document viewer."""
    all_docs = {}
    tab_html_parts = []

    for i, doc in enumerate(documents_config["documents"]):
        key = doc["key"]
        page_b64 = load_page_images(doc["pages_dir"])
        sections = load_sections(doc["sections_json"])
        total = max(page_b64.keys())

        all_docs[key] = {
            "title": doc["title"],
            "tab_label": doc.get("tab_label", doc["title"][:30]),
            "sections": sections,
            "total_pages": total,
        }

        active = " active" if i == 0 else ""
        tab_html_parts.append(
            f'<button class="app-btn{active}" data-doc="{key}">{doc.get("tab_label", key)}</button>'
        )

    # Build JS data per document
    multi_js_parts = ["const MULTI_DATA={"]
    first_key = documents_config["documents"][0]["key"]
    for key, info in all_docs.items():
        page_b64 = load_page_images(
            next(d["pages_dir"] for d in documents_config["documents"] if d["key"] == key)
        )
        page_parts = [f'"{k}":"{v}"' for k, v in sorted(page_b64.items())]
        sections_str = json.dumps(info["sections"])
        multi_js_parts.append(f'"{key}":{{')
        multi_js_parts.append(f'  title:{json.dumps(info["title"])},')
        multi_js_parts.append(f'  totalPages:{info["total_pages"]},')
        multi_js_parts.append(f'  sections:{sections_str},')
        multi_js_parts.append(f'  pages:{{{",".join(page_parts)}}}')
        multi_js_parts.append("},")
    multi_js_parts.append("};")
    multi_js_str = "\n".join(multi_js_parts)

    tabs_html = '<div class="app-selector">' + "".join(tab_html_parts) + "</div>"
    first_doc = all_docs[first_key]

    html = HTML_TEMPLATE.replace("{{TITLE}}", first_doc["title"])\
        .replace("{{SUBTITLE}}", first_doc["title"])\
        .replace("{{PAGE_JS}}", "")\
        .replace("{{SECTIONS_JSON}}", json.dumps(first_doc["sections"]))\
        .replace("{{TOTAL_PAGES}}", str(first_doc["total_pages"]))\
        .replace("{{MULTI_MODE}}", "true")\
        .replace("{{MULTI_TABS_HTML}}", tabs_html)\
        .replace("{{MULTI_DATA_JS}}", multi_js_str)

    return html


# ─── HTML TEMPLATE ─────────────────────────────────────────────────────────────
HTML_TEMPLATE = r'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{{TITLE}}</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,wght@0,400;0,500;0,600;0,700&family=Source+Serif+4:wght@400;600;700&family=JetBrains+Mono:wght@400&display=swap" rel="stylesheet">
<style>
:root {
  --bg: #101218;
  --surface: #181b24;
  --surface2: #1f2330;
  --border: #2a2f40;
  --text: #d8dae6;
  --text-dim: #7a7f96;
  --accent: #4d8cf5;
  --accent-glow: rgba(77,140,245,0.12);
  --sidebar-w: 320px;
  --topbar-h: 56px;
}
*{margin:0;padding:0;box-sizing:border-box;}
html,body{height:100%;overflow:hidden;}
body{
  font-family:'DM Sans',system-ui,sans-serif;
  background:var(--bg);
  color:var(--text);
  display:flex;
  flex-direction:column;
}
.topbar{
  height:var(--topbar-h);
  background:var(--surface);
  border-bottom:1px solid var(--border);
  display:flex;
  align-items:center;
  padding:0 20px;
  gap:14px;
  flex-shrink:0;
}
.topbar .logo{
  font-family:'Source Serif 4',serif;
  font-weight:700;
  font-size:16px;
  color:var(--accent);
  white-space:nowrap;
}
.topbar .sep{width:1px;height:28px;background:var(--border);}
.topbar .title{
  font-size:13px;
  color:var(--text-dim);
  white-space:nowrap;
  overflow:hidden;
  text-overflow:ellipsis;
  flex:1;
}
.topbar .page-indicator{
  flex-shrink:0;
  font-size:12px;
  color:var(--text-dim);
  font-family:'JetBrains Mono',monospace;
  background:var(--surface2);
  padding:4px 10px;
  border-radius:6px;
}
/* App selector for multi-doc */
.app-selector{
  display:flex;gap:3px;
  background:var(--bg);
  border-radius:7px;
  padding:3px;
  flex-shrink:0;
}
.app-btn{
  padding:5px 14px;border-radius:5px;border:none;
  background:transparent;color:var(--text-dim);
  font-family:'DM Sans',sans-serif;font-size:12px;font-weight:500;
  cursor:pointer;transition:all .2s;white-space:nowrap;
}
.app-btn:hover{color:var(--text);}
.app-btn.active{
  background:var(--accent);color:#fff;
  box-shadow:0 2px 8px rgba(77,140,245,0.3);
}
.layout{flex:1;display:flex;overflow:hidden;}
.sidebar{
  width:var(--sidebar-w);min-width:var(--sidebar-w);
  background:var(--surface);border-right:1px solid var(--border);
  display:flex;flex-direction:column;overflow:hidden;
}
.sidebar-search{
  padding:10px 12px;border-bottom:1px solid var(--border);flex-shrink:0;
}
.sidebar-search input{
  width:100%;background:var(--bg);border:1px solid var(--border);
  border-radius:6px;padding:7px 10px;color:var(--text);
  font-size:12px;font-family:'DM Sans',sans-serif;outline:none;
}
.sidebar-search input:focus{border-color:var(--accent);}
.sidebar-scroll{flex:1;overflow-y:auto;padding:4px 0 20px;}
.sidebar-scroll::-webkit-scrollbar{width:3px;}
.sidebar-scroll::-webkit-scrollbar-thumb{background:var(--border);border-radius:3px;}
.group-label{
  font-size:9px;font-weight:700;text-transform:uppercase;
  letter-spacing:1.2px;color:var(--text-dim);padding:14px 14px 4px;
}
.nav-item{
  display:flex;align-items:center;gap:7px;padding:6px 14px;
  cursor:pointer;border-left:3px solid transparent;
  font-size:11.5px;color:var(--text-dim);transition:all .12s;line-height:1.35;
}
.nav-item:hover{background:var(--accent-glow);color:var(--text);}
.nav-item.active{
  border-left-color:var(--accent);background:var(--accent-glow);
  color:var(--accent);font-weight:600;
}
.nav-item .ico{width:16px;text-align:center;font-size:11px;flex-shrink:0;}
.nav-item .lbl{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.nav-item .pg{
  flex-shrink:0;font-size:9px;font-family:'JetBrains Mono',monospace;
  color:var(--text-dim);opacity:0.5;
}
.nav-item.hidden{display:none;}
.group-label.hidden{display:none;}
.main{
  flex:1;overflow-y:auto;display:flex;flex-direction:column;
  align-items:center;padding:20px 16px 80px;gap:12px;background:#0c0d12;
}
.main::-webkit-scrollbar{width:6px;}
.main::-webkit-scrollbar-thumb{background:var(--border);border-radius:4px;}
.page-img{
  width:100%;max-width:820px;border:1px solid var(--border);
  border-radius:3px;box-shadow:0 4px 30px rgba(0,0,0,0.5);
  background:#fff;transition:max-width .2s ease;
}
.page-label{
  font-size:10px;color:var(--text-dim);
  font-family:'JetBrains Mono',monospace;
  text-align:center;margin-top:-4px;margin-bottom:4px;
}
.zoom-bar{
  position:fixed;bottom:16px;right:16px;display:flex;
  align-items:center;gap:2px;background:var(--surface);
  border:1px solid var(--border);border-radius:8px;padding:3px;
  z-index:50;box-shadow:0 4px 16px rgba(0,0,0,0.4);
}
.zoom-btn{
  width:30px;height:30px;display:flex;align-items:center;
  justify-content:center;background:transparent;border:none;
  color:var(--text);font-size:15px;cursor:pointer;border-radius:4px;
}
.zoom-btn:hover{background:var(--accent-glow);}
.zoom-level{
  font-size:11px;color:var(--text-dim);
  font-family:'JetBrains Mono',monospace;
  padding:0 5px;min-width:40px;text-align:center;
}
@media(max-width:800px){
  .sidebar{display:none;}
  .main{padding:8px 4px 60px;}
  .page-img{border-radius:0;}
}
</style>
</head>
<body>
<div class="topbar">
  <div class="logo">Doc Viewer</div>
  <div class="sep"></div>
  {{MULTI_TABS_HTML}}
  <div class="title" id="docTitle">{{SUBTITLE}}</div>
  <div class="page-indicator" id="pageIndicator">—</div>
</div>
<div class="layout">
  <nav class="sidebar">
    <div class="sidebar-search"><input type="text" id="searchInput" placeholder="Filter sections…" /></div>
    <div class="sidebar-scroll" id="sidebarScroll"></div>
  </nav>
  <main class="main" id="mainContent"></main>
</div>
<div class="zoom-bar">
  <button class="zoom-btn" id="zoomOut" title="Zoom out">−</button>
  <div class="zoom-level" id="zoomLevel">100%</div>
  <button class="zoom-btn" id="zoomIn" title="Zoom in">+</button>
  <button class="zoom-btn" id="zoomFit" title="Fit width">⤢</button>
</div>
<script>
// ── Data ──
{{PAGE_JS}}
{{MULTI_DATA_JS}}
const MULTI_MODE = {{MULTI_MODE}};
let SECTIONS = {{SECTIONS_JSON}};
let TOTAL_PAGES = {{TOTAL_PAGES}};
let currentIdx = 0;
let zoomPct = 100;
let currentDoc = null;

function getPageData(p) {
  if (MULTI_MODE && currentDoc && MULTI_DATA[currentDoc]) {
    return MULTI_DATA[currentDoc].pages[String(p)];
  }
  return PAGE_DATA[String(p)];
}

// ── Multi-doc switching ──
if (MULTI_MODE) {
  const keys = Object.keys(MULTI_DATA);
  currentDoc = keys[0];
  SECTIONS = MULTI_DATA[currentDoc].sections;
  TOTAL_PAGES = MULTI_DATA[currentDoc].totalPages;
  document.getElementById('docTitle').textContent = MULTI_DATA[currentDoc].title;

  document.querySelectorAll('.app-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.app-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentDoc = btn.dataset.doc;
      SECTIONS = MULTI_DATA[currentDoc].sections;
      TOTAL_PAGES = MULTI_DATA[currentDoc].totalPages;
      document.getElementById('docTitle').textContent = MULTI_DATA[currentDoc].title;
      currentIdx = 0;
      render();
    });
  });
}

// ── Sidebar ──
function buildSidebar() {
  const el = document.getElementById('sidebarScroll');
  let html = '';
  let lastGroup = '';
  SECTIONS.forEach((sec, i) => {
    if (sec.group !== lastGroup) {
      lastGroup = sec.group;
      html += '<div class="group-label" data-group="'+sec.group+'">' + sec.group + '</div>';
    }
    const ps = sec.pages;
    const pgLabel = ps.length === 1 ? 'p.' + ps[0] : 'p.' + ps[0] + '–' + ps[ps.length-1];
    html += '<div class="nav-item' + (i===currentIdx?' active':'') + '" data-idx="'+i+'">'
      + '<span class="ico">'+sec.icon+'</span>'
      + '<span class="lbl">'+sec.label+'</span>'
      + '<span class="pg">'+pgLabel+'</span></div>';
  });
  el.innerHTML = html;
  el.querySelectorAll('.nav-item').forEach(n => {
    n.addEventListener('click', () => { currentIdx = parseInt(n.dataset.idx); render(); });
  });
  const active = el.querySelector('.nav-item.active');
  if (active) active.scrollIntoView({block:'nearest'});
}

// ── Pages ──
function renderPages() {
  const main = document.getElementById('mainContent');
  const sec = SECTIONS[currentIdx];
  let html = '';
  sec.pages.forEach(p => {
    const b64 = getPageData(p);
    if (b64) {
      html += '<img class="page-img" src="data:image/jpeg;base64,' + b64 + '" alt="Page '+p+'" style="max-width:'+Math.round(820*zoomPct/100)+'px;" loading="lazy" />';
      html += '<div class="page-label">Page ' + p + ' of ' + TOTAL_PAGES + '</div>';
    } else {
      html += '<div class="page-label" style="color:#f66;">Page ' + p + ' — image not found</div>';
    }
  });
  main.innerHTML = html;
  main.scrollTop = 0;
  const ps = sec.pages;
  document.getElementById('pageIndicator').textContent =
    ps.length === 1 ? 'Page ' + ps[0] + ' / ' + TOTAL_PAGES : 'Pages ' + ps[0] + '–' + ps[ps.length-1] + ' / ' + TOTAL_PAGES;
}

function render() { buildSidebar(); renderPages(); }

// ── Search ──
document.getElementById('searchInput').addEventListener('input', e => {
  const q = e.target.value.toLowerCase().trim();
  const items = document.querySelectorAll('.nav-item');
  const groups = document.querySelectorAll('.group-label');
  if (!q) { items.forEach(n=>n.classList.remove('hidden')); groups.forEach(g=>g.classList.remove('hidden')); return; }
  const vis = new Set();
  items.forEach(n => {
    const sec = SECTIONS[parseInt(n.dataset.idx)];
    const match = (sec.label+' '+sec.group+' '+sec.id).toLowerCase().includes(q);
    n.classList.toggle('hidden', !match);
    if (match) vis.add(sec.group);
  });
  groups.forEach(g => g.classList.toggle('hidden', !vis.has(g.dataset.group)));
});

// ── Zoom ──
function applyZoom() {
  document.getElementById('zoomLevel').textContent = zoomPct+'%';
  document.querySelectorAll('.page-img').forEach(img => { img.style.maxWidth = Math.round(820*zoomPct/100)+'px'; });
}
document.getElementById('zoomIn').addEventListener('click', () => { zoomPct=Math.min(200,zoomPct+15); applyZoom(); });
document.getElementById('zoomOut').addEventListener('click', () => { zoomPct=Math.max(30,zoomPct-15); applyZoom(); });
document.getElementById('zoomFit').addEventListener('click', () => { zoomPct=100; applyZoom(); });

// ── Keyboard ──
document.addEventListener('keydown', e => {
  if (e.altKey && e.key==='ArrowDown') { e.preventDefault(); currentIdx=Math.min(SECTIONS.length-1,currentIdx+1); render(); }
  if (e.altKey && e.key==='ArrowUp') { e.preventDefault(); currentIdx=Math.max(0,currentIdx-1); render(); }
});

render();
</script>
</body>
</html>'''


# ─── MAIN ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Generate self-contained HTML viewer from rasterized PDF pages")
    parser.add_argument("--pages-dir", help="Directory containing page-NN.jpg files")
    parser.add_argument("--output", required=True, help="Output HTML file path")
    parser.add_argument("--title", default="Document Viewer", help="Document title")
    parser.add_argument("--subtitle", default="", help="Subtitle shown in top bar")
    parser.add_argument("--sections-json", help="Path to sections definition JSON")
    parser.add_argument("--multi", help="Path to multi-document manifest JSON (overrides single-doc options)")
    args = parser.parse_args()

    if args.multi:
        with open(args.multi, "r") as f:
            manifest = json.load(f)
        html = build_multi_doc_html(manifest, args.output)
    else:
        if not args.pages_dir or not args.sections_json:
            print("ERROR: --pages-dir and --sections-json required for single-doc mode", file=sys.stderr)
            sys.exit(1)

        page_b64 = load_page_images(args.pages_dir)
        sections = load_sections(args.sections_json)
        total_pages = max(page_b64.keys())

        page_js = build_page_js(page_b64)
        sections_json = json.dumps(sections)
        subtitle = args.subtitle or args.title

        html = build_single_doc_html(args.title, subtitle, page_js, sections_json, total_pages)

    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
    with open(args.output, "w") as f:
        f.write(html)

    size_mb = os.path.getsize(args.output) / 1024 / 1024
    print(f"Generated: {args.output} ({size_mb:.1f} MB)")


if __name__ == "__main__":
    main()
