# CalGEM Underground Injection Control (UIC) — Reference

## Source Regulations
CCR Title 14: §1720.1, §1724.5–§1724.13, §1748 (offshore)
Safe Drinking Water Act (SDWA), 40 CFR Part 146
CalGEM–Water Board MOA (2018 revised, 2020 updated)

---

## Key Definitions (§1720.1)

- **Area of Review (AoR) (§1720.1(a)):** Area around each injection well. Either: (1) calculated lateral distance of pressure/temperature influence, or (2) fixed ¼-mile radius.
- **Injection Well (§1720.1(f)):** Well into which fluids are injected as part of a UIC project. Gas storage wells are NOT injection wells.
- **Injection Zone (§1720.1(g)):** 3D space where injected fluid is anticipated to occupy. May include multiple formations.
- **USDW (§1720.1(q)):** Aquifer not EPA-exempted; supplies/could supply public water system; <10,000 mg/L TDS.
- **Mechanical Integrity (§1720.1(j)):** All barriers (tubing, packer, wellhead, casing) reliably contain pressure and are leak-free.
- **Surface Expression (§1720.1(n)):** Flow/release from subsurface to surface outside a wellbore, apparently caused by injection.
- **Low-Energy Seep (§1720.1(h)):** Low-energy, low-temperature surface expression; not injected fluid; contained and monitored.
- **Project Approval Letter (PAL) (§1720.1(l)):** Written Division approval of a UIC project with specific conditions.

### Injection Well Types
- **Waterflood (§1720.1(t)):** Water/water-based liquid for EOR
- **Steamflood (§1720.1(m)):** Steam for EOR of other producing wells
- **Cyclic Steam (§1720.1(b)):** Injects steam, then produces hydrocarbons from same well
- **Low-Use Cyclic Steam (§1720.1(i)):** ≤24 days injection/yr AND ≤12,000 bbl/yr for past 5 years, no known surface expressions
- **Disposal (§1720.1(c)):** Primarily for disposal, not EOR

---

## Project Approval (§1724.6)

- PAL required before any injection
- Division consults with State/Regional Water Quality Control Board
- PAL specifies: approved injection zone (cannot include USDW), conditions, location/nature of project
- Division may specify limited duration
- PAL reviewed at least every 3 years — subject to suspension, modification, or rescission
- Modifications require prior Division approval (addendum or revised PAL)
- Transfer: New operator must meet with Division within 60 days

## Project Data Requirements (§1724.7)

### Engineering Study (§1724.7(a)(1))
- AoR determination (calculations, variables, citations, assumptions)
- Map of AoR: all wells within/adjacent, water supply wells, underground activities
- Casing diagrams (per §1724.7.1) for all wells in AoR penetrating injection zone or deeper
- Flood-pattern map with injection, production, P&A wells, unit boundaries

### Geologic Study (§1724.7(a)(2))
- Reservoir characteristics: porosity, permeability, thickness, extent, fracture gradient, T&P, saturations
- Reservoir fluid data: gravity, viscosity, water quality, H₂S, gas gravity
- Structural contour maps (top and base of each injection zone)
- Isopach maps
- ≥2 geologic cross sections (along strike + perpendicular) through ≥3 wells
- Representative e-log below deepest producing/injection zone

### Injection Plan (§1724.7(a)(3))
- Primary purpose, facilities map, P&ID
- Anticipated duration, daily rate (by well), cumulative net volume
- All project wells identified
- Monitoring system/SOPs
- Injection method, string configuration, BHA
- Corrosion prevention measures
- Injection liquid source and analysis (per §1724.7.2)

### Liquid Analysis (§1724.7.2)
- TDS, TPH as crude oil, major cations (Ca, Mg, Na, K, Fe, Mn, Sr, B), major anions (Cl, SO₄, HCO₃, CO₃, Br, I)
- Total alkalinity/hydroxide, electrical conductance, pH, temperature
- Lab must be SWRCB-certified; submits data directly to Division digitally

---

## AoR Evaluation (§1724.8)

- All wells in AoR penetrating injection zone or deeper must be evaluated for fluid migration potential
- Division evaluates cementing records; may require cement eval log if inadequate
- P&A wells must have cement per §1723.1
- Division may require: re-entry, examination, re-plug, remediation, monitoring
- Safe assumption: well is not a conduit if it has verified 100 linear ft or calculated 150 linear ft of cement above injection zone

## Non-Expansion AoR (Appendix 3 Checklist)
For adding wells to an already-approved project:
- Well-specific casing diagram and cement data
- Demonstration that well won't act as conduit
- Update to project well list
- Any changed conditions since original approval

---

## Operating Requirements (§1724.10)

### Tubing & Packer (§1724.10(g))
- Required for all injection wells; packer set no more than 100 ft above approved injection zone
- Exceptions: steamflood, cyclic steam, or Division-approved waiver (no USDW penetration, multiple cemented casing strings, or other justification)
- Wells not required to have T&P before 4/1/2019: deadline April 1, 2021

### MASIP (§1724.10.3)
- MASIP = lower of: (1) calculated value [(IG – IFG) × TVD], or (2) most recent successful pressure test pressure
- IG = fracture gradient × 0.95 (or Division-approved multiplier)
- Fracture gradient determined by step-rate test or Division-approved method
- Division may approve higher MASIP if operator demonstrates confinement and no fracture propagation

### Step-Rate Test (§1724.10.3(e))
- Shut in until BHP ≈ formation pressure
- Equal-duration steps; first 3 below fracture gradient
- Real-time digital BHP and surface pressure recording (≥1 reading/second)
- 24-hour advance notice to district office

### Continuous Pressure Monitoring (§1724.10.4)
- Continuously recorded at all times well is approved for injection
- Monthly: report highest instantaneous pressure per well
- Records maintained while approved + 3 years after
- SCADA preferred but not required
- Devices calibrated per manufacturer specs

### Monthly Injection Report (§1724.10(c))
Filed on or before last day of each month for preceding month.

### Chemical Analysis (§1724.10(d))
New analysis required whenever injection liquid source changes.

### Wells Near Water Supply Wells (§1724.10(e))
Within 500 linear ft of water supply well perforations: annual reporting of treatment process, SDS for additives, aggregate volumes, additive purposes.

---

## MIT Part 1 — Casing Integrity (§1724.10.1)

- Prior to first injection, then every 5 years (every 1 year for gas disposal)
- Also after repositioning/replacement of downhole equipment, or on Division request
- 48-hour advance notice to district office
- Min 200 psi above surface pressure; MASIP ≤ test pressure used
- Pass: ≤3% change over 30 minutes (cyclic steam: up to 10% increase OK)
- Results submitted digitally within 60 days
- Failed: notify Division immediately; no injection without written reapproval
- Alternative: annular pressure monitoring program (§1724.10.1(c)) — min 100 psi annular, 500 psi test, SCADA preferred, 5-min recording intervals
- Pre-4/1/2019 wells not previously required: deadline April 1, 2024 (gas disposal: April 1, 2020)

## MIT Part 2 — Fluid Migration (§1724.10.2)

- Within 3 months after first injection, then every 2 years
- Disposal wells: every 1 year
- Low-use cyclic steam: every 5 years
- Steamflood with T&P: every 5 years
- Also after >25% pressure variance within 48 hours
- Methods: radioactive tracer survey (§1724.10.2(d)), temperature survey (§1724.10.2(e)), noise log (§1724.10.2(f))
- Written Division approval of method required beforehand
- Investigate anomalies immediately; notify Division if fluid migration suspected

---

## Surface Expressions (§1724.11, §1724.12)

### Prohibition
Underground injection projects shall not result in any surface expression. (§1724.11(a))

### Response Radii (§1724.11(d))
- Within 150 ft of wellhead: cease injection immediately
- Still flowing >24 hrs + within 300 ft: cease injection
- Still flowing >5 days + within 600 ft: cease injection
- Still flowing >10 days: Division determines expanded radius
- Cannot resume without written Division approval

### Projects Known to Cause Surface Expressions (§1724.11(b))
- Surface expression monitoring & prevention plan required
- 24/7 on-site staff
- Daily visual inspections
- Continuous injection rate monitoring
- >25% pressure variance in 48 hrs OR >30% rate variance: notify Division, diagnose within 12 hrs
- If threat or inconclusive after 72 hrs: cease injection within 300 ft

### Containment (§1724.12)
- Licensed PE design, sign-off, and construction supervision
- Include in Spill Contingency Plan
- Daily flow monitoring (unless Division approves less)
- Existence of surface expression (except low-energy seep) = violation regardless of containment

---

## Cease Injection Triggers (§1724.13)

Must cease and notify Division immediately if:
1. MIT not performed as required
2. Failed MIT or any indication of lack of integrity
3. Indication of tubing/packer/cement/casing failure
4. Visible surface damage from injection
5. Fluids not confined to approved zone
6. Damage to life/health/property/resources occurring
7. Production reporting not provided per PRC §3227
8. Well becomes idle per PRC §3008(d)
9. Division instructs cessation in writing

Each day of unauthorized injection = separate violation. Injection lines must be disconnected if no current approval.

---

## Periodic Project Review
Division reviews each project at least annually (policy) / at least every 3 years (regulation). Reviews:
- Consistency with PAL conditions
- Required testing completed
- Changes to project (new wells drilled, reworked, abandoned in AoR)
- Fluid confinement to approved zone
- No damage occurring from injection
