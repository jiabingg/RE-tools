# CalGEM Idle Well Regulations — Reference

## Source Regulations
CCR Title 14: §1752, §1760, §1772, §1772.1, §1772.1.1, §1772.1.2, §1772.1.3, §1772.1.4, §1772.2, §1772.3, §1772.4, §1772.5, §1772.6, §1772.7
PRC: §3008, §3206, §3206.1
AB 1866 (Sept 2024, effective Jan 1, 2025)

---

## Key Definitions (§1760)

- **Idle Well (§1760(n)):** 24 consecutive months zero production (oil, gas, water for stimulation) or injection. Exits idle after 6 continuous months production/injection or P&A per §3208. Does not include active observation wells.
- **Long-Term Idle Well (§1760(o)):** Idle ≥ 8 years.
- **Low-Priority Idle Well (§1760(p)):** Does NOT penetrate USDW, no surface pressure, not open to atmosphere, not in geologic hazard area, not critical/urban/environmentally sensitive.
- **USDW (§1760(x)):** Aquifer not EPA-exempted; supplies or could supply public water system; contains <10,000 mg/L TDS.
- **Freshwater (§1760(j)):** ≤ 3,000 mg/L TDS.
- **Urban Area (§1760(y)):** ≥ 25 establishments/residences, perimeter 300 ft beyond outer structures.
- **Partially Plugged (§1752):** Division-approved partial plug. Pressure test every 60 months. Exempt from §1772.1 and §1772.1.2.
- **Active Observation Well (PRC §3008(c)):** Gathering reservoir data only. Annual summary to Division.

## Idle Start Date Calculation
First day of month after 24th consecutive month of zero reported volumes.
Example: Last production Jan 2009 → Idle Start Date = Feb 1, 2011.

## Compliance vs. Roll-in Wells
- **Compliance Wells:** Idle before April 1, 2019. Subject to Testing Compliance Work Plan §1772.1.4. All testing by April 1, 2025.
- **Roll-in Wells:** Idle after April 1, 2019. Deadlines run from date they become idle.

## Exiting Idle Status
- P&A per PRC §3208
- 6 continuous months production/injection (exit date = 1st day of month after 6th month)
- NOT: converting to observation well, transferring to new operator

---

## Three Required Tests (§1772.1)

### 1. Fluid Level Test — §1772.1(a)(1)
- **When:** Within 24 months of becoming idle, repeat every 24 months
- **Method:** Acoustical, mechanical, or other reliable method
- **Purpose:** Determine if fluid is above base of USDW
- **USDW presumption:** If operator hasn't demonstrated USDW location, fluid is presumed above USDW
- **Post-4/1/2025:** If fluid is above USDW, must do casing pressure test within 90 days
- **Exemption:** Not required if wellbore does not penetrate USDW
- **Results:** Submit within 60 days digital (30 days if above USDW)

### 2. Casing Pressure Test — §1772.1(a)(2)
- **When:** Within 24 months of becoming idle
- **Depth:** Surface to 100 ft MD above uppermost perf, above deepest cemented casing shoe, or above top of landed liner — whichever is highest
- **Auto-fail:** If well cannot be safely tested, deemed failed
- **Retest intervals by PSI:**
  - 200 psi above surface → retest within 48 months
  - 500 psi above surface → retest within 72 months
  - 1,000 psi above surface → retest within 96 months
  - Alternative methods §1772.1.1(b)(c)(d) → retest within 48 months

### 3. Clean Out Tag — §1772.1(a)(3)
- **When:** Within 8 years of becoming idle
- **Method:** Open-ended tubing or gauge ring of minimum P&A diameter
- **Depth:** Must reach at least 25 ft below uppermost perf in lowermost non-abandoned zone
- **Retest:** Every 48 months (less frequent with Division approval)

## Pressure Test Parameters (§1772.1.1)
- Test with liquid (unless Division approves gas)
- Stable fluid column, free of excess gases
- Min 200 psi above surface pressure
- Calibrated gauge, accuracy ≤1% of test pressure
- Recorded at least once per minute
- **Pass:** ≤3% pressure change over continuous 30 minutes
- **Steam exception:** In cyclic/steamflood AoR, up to 10% increase is a pass
- Results submitted digitally within 60 days in tabular format

## Alternative Test Methods
- **Inert Gas Depression (§1772.1.1(b)):** Min computed pressure ≥500 psi. Pass = ±1% over 60 min.
- **Alternate MIT (§1772.1.1(c)):** Magnetic flux, ultrasonic, imaging + cement eval log. Division case-by-case approval.
- **Passive/Caliper (§1772.1.1(d)):** Low-priority wells only. Division-approved protocols.

## Failed Tests (§1772.1(b))
Within 12 months, operator must: (A) bring into compliance, (B) partial P&A per §1752, (C) full P&A per §3208, or (D) schedule under approved IWMP or Testing Waiver Plan.

## Testing Compliance Work Plan (§1772.1.4)
For wells idle as of 4/1/2019. Due 6/1/2019. Benchmarks: 5% by 4/2020, 15% by 4/2021, 30% by 4/2022, 50% by 4/2023, 75% by 4/2024, 100% by 4/2025. Each untested well = separate violation.

---

## 15-Year Engineering Analysis (§1772.1.2)
- **Trigger:** End of month when well has been idle 15 years
- **Purpose:** Prove viable to return to operation
- **Reservoir data (§1772.1.2(b)):** API, future use statement, reservoir units, e-log, structural contour map
- **Mechanical data (§1772.1.2(c)/§1772.1.3):** Complete casing diagram, cement records, wellbore path, current passing pressure test + clean out tag
- **If not viable:** Division provides basis → operator gets ≥30 days → if still not viable → P&A within 12 months or schedule on plan
- **Multi-well efficiency:** Reservoir data for same field can be referenced, not resubmitted (§1772.1.2(e))

---

## Plans & Waivers

### Testing Waiver Plan (§1772.2)
- Schedule P&A within up to 8 years
- ≥10% P&A'd each year
- Testing waived while in compliance
- If operator fails schedule: Division may cancel entire plan → test ALL wells within 90 days → no new plan until full compliance

### IWMP (§1772.3 / PRC §3206)
- Filed in lieu of idle well fees (due May 1)
- Up to 8-year plan, annual review
- AB 1866 (eff. 1/1/2025): Now covers ALL idle wells (not just long-term)
- Elimination rates by statewide count: 0–250: 5/6/8%, 251–1250: 6/8/10%, 1251–3000: 7/10/15%, 3001+: 15/18/20% (CY2025-27/2028-29/2030+)
- Failure: cancelled → pay all fees → no new IWMP for 2 years

### Prioritization Factors (§1772.4)
Critical/urban/environmentally sensitive, geologic hazards, surface pressure, access obstacles, downhole issues, fluid above freshwater/USDW, age, other threats, operational efficiencies.

---

## Fees (2025 — AB 1866)
| Years Idle | Previous | New (2025) |
|-----------|----------|------------|
| 0–2.99 | $0 | $1,000 |
| 3–7.99 | $150 | $2,500 |
| 8–14.99 | $300 | $5,000 |
| 15–19.99 | $750 | $12,500 |
| 20+ | $1,500 | $22,500 |

Late: 10% penalty + 1.5%/mo interest. Referred to State Controller after 2 months. Non-payment = desertion evidence → §3237 order to P&A.

## Observation Wells (§1772.5)
Casing pressure test within 6 months (unless tested in past 5 years). Retest every 60 months. Pre-existing (4/1/2019): half by 4/2021, all by 4/2023.

## Inventory & Evaluation (§1772)
Due Jan 31 annually. Includes: API, spud date, obstacles, MI test results, USDW/freshwater penetration, pressures, critical/urban/sensitive status, geologic hazards, downhole issues, partial plug status.

## Other
- ½-mile USDW exception (§1772.1(e)): +2 years before testing required
- Inaccessible wells (§1772.1(d)): Monitoring plan within 1 year
- Gas storage wells (§1772.7): Exempt if tested under §1726.6
- ~35,000 idle wells statewide
- 24-hour notice before testing; results within 60 days (30 if above USDW)
