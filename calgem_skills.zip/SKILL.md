---
name: calgem-regulatory-knowledgebase
description: "CalGEM oil & gas regulatory knowledge base for California. Use this skill whenever the user asks about CalGEM permitting, idle wells, underground injection control (UIC), well operations, plugging & abandonment, oil and gas forms (OG106, OG150, OG160, OG30A, OGD7), CEQA requirements for wells, well bonding, mechanical integrity testing, injection project approval, area of review, surface expressions, idle well fees, idle well management plans (IWMP), testing waiver plans, 15-year engineering analysis, oil and gas assessments, rework/redrill requirements, field rules, WellSTAR, or any California oil and gas regulatory compliance topic. Also trigger when the user asks to create cheatsheets, knowledge base pages, flashcard quizzes, or interactive reference materials about CalGEM regulations. This skill covers CCR Title 14, PRC Division 3, AB 1866, and all related CalGEM programs."
---

# CalGEM Regulatory Knowledge Base Skill

## Purpose
Create interactive HTML knowledge base pages, cheatsheets, and quiz tools for California Geologic Energy Management Division (CalGEM) regulatory topics. This skill captures the design patterns, content structure, and regulatory knowledge needed to produce high-quality reference materials for oil and gas operators and engineers.

## When to Use
- User asks about ANY CalGEM regulatory topic (permitting, idle wells, UIC, P&A, forms, fees, compliance, etc.)
- User wants a cheatsheet, knowledge base page, or interactive reference
- User asks to create flashcard quizzes for CalGEM regulatory knowledge
- User asks about California oil & gas well permitting, testing, or operational requirements
- User mentions specific forms (OG106, OG150, etc.) or regulation sections (§1724, §1772, etc.)
- User asks about idle well fees, IWMPs, testing waiver plans, or AB 1866

## Quick Regulatory Reference

### Key CalGEM Programs
| Program | Key Regulations | Scope |
|---------|----------------|-------|
| Permitting | PRC §3203, CCR §1720–§1723 | Drill, rework, redrill, P&A permits |
| Idle Wells | CCR §1752, §1760, §1772–§1772.7, PRC §3008, §3206, AB 1866 | Testing, management plans, fees |
| UIC | CCR §1724.5–§1724.13, §1720.1 | Injection projects, MIT, pressure monitoring |
| Underground Gas Storage | CCR §1726–§1726.10 | Gas storage wells (separate from UIC) |
| Pipelines & Facilities | CCR §1774–§1778 | Pipeline integrity, secondary containment |

### Key Forms Quick Reference
| Form | Name | Use |
|------|------|-----|
| OG106 | Notice of Intention | ALL permits (drill, rework, P&A) — replaces OG105/107/108/123 |
| OG150 | Agent Designation | Designate CA-resident agent — replaces OG134A/B, OGD42D |
| OGD7 | Contact Questionnaire | Technical contact info, submitted with OG150 |
| OG160 | Oil and Gas Bond | Individual or blanket bond — replaces all prior bond forms |
| OG30A | Disposition/Transfer | Notify CalGEM of well/facility sale or transfer |

### Key Numbers
| Item | Value |
|------|-------|
| NOI validity | 24 months from receipt (PRC §3203(a)) |
| Idle well trigger | 24 consecutive months zero volumes |
| Return to active | 6 continuous months production/injection |
| Long-term idle | ≥ 8 years idle |
| Fluid level test | Every 24 months |
| Casing pressure test (idle) | Within 24 mo., retest 48–96 mo. |
| Clean out tag | Within 8 years, retest 48 mo. |
| 15-year engineering analysis | By end of month 15 idle |
| Post-failure remedy | 12 months |
| UIC PAL review cycle | At least every 3 years |
| MIT Part 1 (UIC casing) | Every 5 years (1 yr gas disposal) |
| MIT Part 2 (UIC fluid migration) | Every 2 years (varies by type) |
| IWMP / Waiver Plan max | 8 years |
| Assessment rate 2025/26 | $1.2796 per equiv. BBL |

---

## How to Build a CalGEM Knowledge Base Page

### Design Specifications
Follow these exact specifications for consistency across all CalGEM reference pages:

**Fonts:** Inter (body) + JetBrains Mono (monospace for citations, numbers, form names)
```
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap');
```

**Theme:** Warm light scheme (NOT dark mode)
- Background: `#f8f6f1` (warm cream)
- Surface: `#ffffff` (white cards)
- Surface2: `#f0ede6` (definition boxes, table headers)
- Text: `#2c2416` (dark brown), `#5c5243` (secondary), `#8a7f6e` (muted)
- Header: `#1e3a5f` (navy) with `#fbbf24` (gold) accent text

**Color Accents (for cards, badges, alerts):**
- Amber: `#b45309` text, `#fef3c7` bg, `#f59e0b` border
- Blue: `#1d4ed8` text, `#dbeafe` bg, `#3b82f6` border
- Green: `#047857` text, `#d1fae5` bg, `#10b981` border
- Red: `#b91c1c` text, `#fee2e2` bg, `#ef4444` border
- Purple: `#6d28d9` text, `#ede9fe` bg, `#8b5cf6` border
- Cyan: `#0e7490` text, `#cffafe` bg, `#06b6d4` border

**Font Sizes (minimum for readability):**
- Body text: 15–16px
- Card headings: 17–18px
- Table text: 14–15px
- Badge/citation: 10–11px
- Detail/secondary: 14px
- Notes/warnings: 14–15px

### Page Structure Template
Every knowledge base page follows this structure:

```
1. HEADER — Navy background, gold title, subtitle, regulation citations
2. TAB BAR — JetBrains Mono, navy active tab with gold text
3. TABBED SECTIONS — Each containing:
   - Cards with colored left borders (5px)
   - Quick Reference boxes (amber border, key-value pairs)
   - Definition boxes (colored left border, background #f0ede6)
   - Flow steps (numbered, amber numbers)
   - Tables (monospace headers, hover highlight)
   - Warning boxes (red bg) for compliance deadlines
   - Success boxes (green bg) for exemptions
   - Note boxes (amber bg) for tips
   - SVG diagrams for process flows and charts
   - Checklists with ▸ markers
4. QUIZ TAB — Interactive flashcards (see below)
```

### Flashcard Quiz Implementation
Every knowledge base page should include a quiz tab with these features:

**Card Behavior:**
- Click to expand answer below question (NOT 3D flip — causes text clipping)
- Question on white card with amber border
- Answer on navy panel that expands below
- `white-space: pre-line` on answer text for multiline formatting
- No fixed height — answer area grows with content

**Scoring:**
- "✓ Knew It" and "✗ Didn't Know" buttons
- Progress dots (green = correct, red = incorrect, amber = current)
- Click any dot to jump to that card
- Final score with percentage and feedback message
- Shuffle on restart

**Answer Quality:**
- Every answer must be COMPLETE — include all relevant details, not abbreviated
- Include specific numbers, deadlines, and thresholds
- Include the regulation citation
- Use line breaks (`\n`) for multi-part answers
- Minimum 25 flashcards per topic

---

## Reference Materials

For detailed regulatory content on specific topics, read the appropriate reference file:

| Topic | Reference File | When to Read |
|-------|---------------|--------------|
| Idle Wells | `references/idle-wells.md` | Any idle well question, fee schedule, IWMP, testing requirements |
| UIC / Injection | `references/uic-injection.md` | Injection projects, MIT, AoR, surface expressions, MASIP |
| Permitting & Forms | `references/permitting-forms.md` | NOI process, forms, bonding, CEQA, rework, P&A |

Read the relevant reference file BEFORE generating content to ensure regulatory accuracy.

---

## Output Checklist
Before delivering any CalGEM knowledge base page, verify:

- [ ] Warm light theme (cream background, NOT dark mode)
- [ ] Font sizes ≥ 15px for body text
- [ ] All regulation citations in JetBrains Mono badges
- [ ] SVG diagrams for at least one process flow
- [ ] Warning boxes for critical deadlines
- [ ] Quick reference table with key numbers
- [ ] Flashcard quiz with ≥ 25 cards and complete answers
- [ ] Answer text uses `white-space: pre-line` for line breaks
- [ ] Card answer panel expands (not 3D flip)
- [ ] All cards have regulation citation references
- [ ] File saved to `/mnt/user-data/outputs/` and presented to user
