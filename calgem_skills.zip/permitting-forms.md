# CalGEM Permitting, Forms & Compliance — Reference

## Source
CalGEM Operator Guidance: conservation.ca.gov/calgem/for_operators
CCR Title 14, Division 2, Chapter 4
PRC Division 3

---

## Permitting Overview

CalGEM administers regulations for ALL oil and gas wells on public and private land and offshore within 3 nautical miles of the California coastline. Operators must obtain permits for drilling, reworking, and P&A of wells. ~55,000 UIC wells in California.

### Universal Permit Form: OG106 (Notice of Intention)
- Used for ALL permit requests: drill new wells, rework, redrill, P&A, supplementary notices
- Replaces: OG105, OG107, OG108, OG123
- Filed in duplicate with the appropriate CalGEM district office
- Must include technical contact name + email on ALL forms
- Valid for 24 months from date CalGEM received it (PRC §3203(a))
- If not commenced within 24 months: deemed canceled, cannot be extended
- Well Status Inquiry letter may be used to request 1-year extension prior to expiration

---

## Drilling New Wells — Step by Step

### Step 1: Designate California Agent
- Form: **OG150** (replaces OG134A, OG134B, OGD42D)
- Must be an individual (not a company) residing in California
- Serves as company contact for all correspondence, permits, and legal process
- Operator may appoint themselves as agent
- Separate form for each designated area of the state
- Submit to district office where well is located
- Also submit: **OGD7** (Contact Questionnaire) — technical contact info

### Step 2: CEQA Compliance
- Must be completed PRIOR to submitting NOI
- Usually involves permits from local land-use agency
- Attach copy of local jurisdiction's Notice of Determination or Notice of Exemption to OG106

### Step 3: Submit NOI (OG106) + Bond (OG160)
- OG106 filed in duplicate with district office
- Attachments: complete drilling program, lease map/plat, lease description, proposed wellbore schematic
- Must be consistent with CalGEM Field Rules — deviations require explanation/justification
- **OG160** (Oil and Gas Bond): individual indemnity or cash bond with each NOI
  - Replaces all prior bond forms (blanket, individual, onshore, offshore, etc.)
  - Individual bond amounts based on well depth
  - Not required if blanket bond already on file

### Step 4: Receive CalGEM Approval (P-Report)
- CalGEM issues Permit to Conduct Well Operations
- P-Report must be posted at drill site at all times
- Lists all mandatory tests and inspections for CalGEM inspectors to witness

### Step 5: Comply with Well Requirements
- Protection of all hydrocarbon zones and fresh waters (casing, cementing, drilling procedures)
- Adequate BOPE (blowout prevention equipment) per MO7
- Proper well spacing (CCR §1721–1721.9)

---

## Rework / Redrill Operations

### Definition (§1720(b))
"Rework" = any operation subsequent to drilling that involves deepening, redrilling, plugging, or permanently altering in any manner the casing of a well or its function.

### Requirements
- Submit OG106 in duplicate
- Include: wellbore schematic diagram, CEQA document (if required)
- Note changes in completion zone, Field, Area for recompletions/redrills/deepenings
- P-Report must be posted at well site at all times
- Adequate BOPE required (MO7). ALL operations in urban areas require BOPE.
- PRC §3219: Operators must maintain well control during ANY operation, with or without permit

---

## Plugging & Abandonment

### Requirements
- Submit OG106 (also for re-entering to replace cement plugs and re-abandon)
- Wellbore schematic must include:
  - Casing intervals and sizes
  - Perforation locations
  - Cement plug depths inside casing
  - Cement location outside casing

### Radioactive Sources (§1722(j))
- Loss of radioactive materials (except tracers for injection surveys) must be promptly reported to:
  - Dept. of Health Services: (916) 327-5106
  - OES 24-hour Emergency: 1-800-852-7550
  - Appropriate CalGEM district office
- Special plugging instructions per §1723(g)

### Conductor Pipe
- Once set, if not to be used (e.g., permit cancelled): must be properly secured or covered at surface
- Contact CalGEM for plugging requirements to minimize contamination and surface hazards

---

## Key Forms Summary

| Form | Name | Purpose | Replaces |
|------|------|---------|----------|
| OG106 | Notice of Intention | ALL permits (drill, rework, P&A, supplementary) | OG105, OG107, OG108, OG123 |
| OG150 | Agent Designation & Org Info Change | Designate CA-resident agent | OG134A, OG134B, OGD42D |
| OGD7 | Contact Questionnaire | Technical contact, submitted with OG150 | — |
| OG160 | Oil and Gas Bond | Individual/blanket, indemnity/cash, onshore/offshore | All prior bond forms |
| OG30A | Disposition/Transfer Notification | Report sale/transfer of wells/facilities | — |

---

## Other Operational Requirements

### Well Disposition/Transfer (OG30A)
- Both seller AND buyer must notify CalGEM
- Due no later than the date the sale/transfer becomes final

### Confidential Status
- Written request with justification to district office
- Per PRC §3234 and CCR §1997.1
- Can be requested at NOI submission or after drilling completion

### Well Maintenance Reporting
- Via WellSTAR system
- Monthly production/injection reporting per PRC §3227

### Field Rules
- Available at CalGEM website per field
- Coiled Tubing Plugging Guidelines
- Bentonite Plugging Guidelines

---

## Compliance — Key Regulatory Packages

| Package | Effective | Scope |
|---------|-----------|-------|
| Idle Well Testing & Management | April 2019 | Fluid level, casing pressure, clean out, 15-yr analysis, IWMP |
| Underground Injection Control | April 2019 | PAL, MIT Parts 1 & 2, pressure monitoring, surface expressions |
| Underground Gas Storage | 2018 | Separate from UIC, covers §1726–1726.10 |
| Oil and Gas Pipelines | 2018 | Pipeline integrity, leak detection, secondary containment |

### MOUs/MOAs
- CalGEM + State Water Board (2018/2020 revised): Coordinates UIC Class II, produced water discharges, enforcement, incidents. Single-permit approach.

---

## Oil & Gas Assessments

### Assessment Rate
Set each June. Rate = CalGEM estimated budget ÷ prior year assessable production.
Imposed per barrel of oil and per 10,000 cubic feet of natural gas.

| FY | Rate per equiv. BBL |
|----|-------------------|
| 2025/26 | $1.2796 |
| 2024/25 | $1.2156 |
| 2023/24 | $1.0108 |
| 2022/23 | $0.8738 |
| 2021/22 | $0.5958 |

### Payment Schedule
- Assessment Notices sent before June 15
- Assessment Roll to State Controller: first Monday in July
- Under $500: due by August 15
- $500+: half by August 15, balance by February 1
- Substantial penalties and interest on delinquent payments

### Key Facts
- No statewide severance tax on oil/gas in California
- Ad valorem (property) taxes administered by each county
- Producers report monthly; file annual reconciliation
